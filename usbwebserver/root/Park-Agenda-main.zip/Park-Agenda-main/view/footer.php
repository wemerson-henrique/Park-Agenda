<footer>
        <div class="alert alert-secondary" align="center" role="alert" 
        style="background-color: #191970; color: #fff;">
          <p> Desenvolvido por Túlio e Wemerson</p>
          <p> Direitos Reservados, Copywriter</p>
        </div>
    </footer>