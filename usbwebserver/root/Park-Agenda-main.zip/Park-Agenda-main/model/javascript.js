function myAlert(params) {
    if (confirm("Desculpe! Voçê não é cadastrado.")) {
        window.location="..\view\login.php";
    }
}